#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <readline/readline.h>
#include <readline/history.h>

#define MAX_COM 80

int takeInput(char* str){
    char* buf;
    buf = readline("osh> ");
    if (strlen(buf) != 0){
        add_history(buf);
        strcpy(str, buf);
        return 0;
    }else{
        return 1;
    }
}

int main(){
    char inputString[MAX_COM];
    pid_t pid;

    // char argvtest[5][10];
    // memset(argvtest, 0, sizeof(argvtest));
    // sprintf(argvtest[0], "-l");
    // sprintf(argvtest[1], "-a");
    // execl("/bin/ls", "ls", argvtest, NULL);

    //execl("/bin/ls", "ls", argvtest[0], NULL);
    // execl("/bin/ls","ls","-l -a", NULL);
    
    while(1){
        char command[MAX_COM];
        char *arg[MAX_COM];

        // get command
        if (takeInput(inputString))
            continue;

        // process
        int n = 1;
        char *p = strtok(inputString, " ");
        strcpy(arg[0], p);
        strcpy(command, p);
        while(arg[n++] = strtok(NULL, " "));
        arg[n-1] = NULL;
        n -= 2;    // arg number

        // exit
        if(strcmp(command, "exit") == 0){
            printf("Process end\n");
            return 0;
        }
        for(int i=n+1;i<MAX_COM;i++){
            arg[i] = NULL;
        }

        // exec
        pid = fork();
        if(pid == 0){
            if (execvp(arg[0], arg) < 0){
                printf("Wrong Command...\n");
            }
            exit(1);
        }else if(pid > 0){
            wait(NULL);
        }else{
            printf("Fork Error\n");
        }
    }
    
}